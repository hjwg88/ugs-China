export enum AxisEnum {
    X = "X",
    Y = "Y",
    Z = "Z",
}
