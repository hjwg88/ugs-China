package com.willwinder.universalgcodesender.connection.xmodem;

/**
 * Created by asirotinkin on 12.11.2014.
 * <p>
 * Original work from here: https://github.com/aesirot/ymodem
 */
class TimeoutException extends Exception {
}

